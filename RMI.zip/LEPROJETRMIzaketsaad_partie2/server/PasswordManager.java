package server;

import common.PasswordEntry;
import common.PasswordManagerRemote;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

public class PasswordManager extends UnicastRemoteObject implements PasswordManagerRemote {
    private final List<PasswordEntry> entries = new ArrayList<>();
    private final String validUsername = "admin";
    private final String validPasswordHash;

    public PasswordManager() throws RemoteException {
        super();
        this.validPasswordHash = hash("1234");
    }

    @Override
    public boolean login(String username, String passwordHash) {
        return validUsername.equals(username) && validPasswordHash.equals(passwordHash);
    }

    @Override
    public synchronized void addEntry(PasswordEntry entry) throws RemoteException {
        if (entry.getService().isEmpty() || entry.getUsername().isEmpty() || entry.getPassword().isEmpty()) {
            throw new RemoteException("Aucun champ ne doit être vide.");
        }
        entries.add(entry);
    }

    @Override
    public synchronized void updateEntry(String service, String username, String newPassword) throws RemoteException {
        for (PasswordEntry entry : entries) {
            if (entry.getService().equals(service) && entry.getUsername().equals(username)) {
                entry.setPassword(newPassword);
                return;
            }
        }
        throw new RemoteException("Entrée introuvable.");
    }

    @Override
    public synchronized void deleteEntry(String service, String username) throws RemoteException {
        entries.removeIf(e -> e.getService().equals(service) && e.getUsername().equals(username));
    }

    @Override
    public synchronized List<PasswordEntry> getAllEntries() {
        return entries;
    }

    private String hash(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] digest = md.digest(password.getBytes());
            return Base64.getEncoder().encodeToString(digest);
        } catch (Exception e) {
            return null;
        }
    }
}
