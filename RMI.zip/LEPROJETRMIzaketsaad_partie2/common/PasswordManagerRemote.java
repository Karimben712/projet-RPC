package common;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

public interface PasswordManagerRemote extends Remote {
    boolean login(String username, String passwordHash) throws RemoteException;
    void addEntry(PasswordEntry entry) throws RemoteException;
    void updateEntry(String service, String username, String newPassword) throws RemoteException;
    void deleteEntry(String service, String username) throws RemoteException;
    List<PasswordEntry> getAllEntries() throws RemoteException;
}
