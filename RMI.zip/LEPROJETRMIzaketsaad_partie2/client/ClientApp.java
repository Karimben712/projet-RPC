package client;

import common.PasswordEntry;
import common.PasswordManagerRemote;

import javax.swing.*;
import java.awt.*;
import java.rmi.Naming;
import java.security.MessageDigest;
import java.util.Base64;

public class ClientApp {
    private static PasswordManagerRemote manager;

    public static void main(String[] args) {
        try {
            manager = (PasswordManagerRemote) Naming.lookup("rmi://localhost/PasswordManager");
            showLoginWindow();
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erreur de connexion au serveur : " + e.getMessage());
        }
    }

    private static void showLoginWindow() {
        JTextField userField = new JTextField();
        JPasswordField passField = new JPasswordField();
        Object[] fields = {
                "Nom d'utilisateur :", userField,
                "Mot de passe :", passField
        };

        int option = JOptionPane.showConfirmDialog(null, fields, "Connexion", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            try {
                String username = userField.getText();
                String password = hash(new String(passField.getPassword()));
                if (manager.login(username, password)) {
                    showAppWindow();
                } else {
                    JOptionPane.showMessageDialog(null, "Identifiants invalides.");
                    showLoginWindow();
                }
            } catch (Exception e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Erreur : " + e.getMessage());
            }
        }
    }

    private static void showAppWindow() throws Exception {
        JFrame frame = new JFrame("Gestionnaire de mots de passe");
        frame.setSize(500, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        DefaultListModel<String> listModel = new DefaultListModel<>();
        JList<String> entryList = new JList<>(listModel);
        refreshList(listModel);

        JTextField serviceField = new JTextField();
        JTextField userField = new JTextField();
        JTextField passField = new JTextField();

        JPanel formPanel = new JPanel(new GridLayout(3, 2));
        formPanel.add(new JLabel("Service :"));
        formPanel.add(serviceField);
        formPanel.add(new JLabel("Nom d'utilisateur :"));
        formPanel.add(userField);
        formPanel.add(new JLabel("Mot de passe :"));
        formPanel.add(passField);

        JPanel buttonPanel = new JPanel();
        JButton addButton = new JButton("Ajouter");
        JButton updateButton = new JButton("Modifier");
        JButton deleteButton = new JButton("Supprimer");

        buttonPanel.add(addButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);

        frame.add(formPanel, BorderLayout.NORTH);
        frame.add(new JScrollPane(entryList), BorderLayout.CENTER);
        frame.add(buttonPanel, BorderLayout.SOUTH);

        addButton.addActionListener(e -> {
            try {
                if (serviceField.getText().isEmpty() || userField.getText().isEmpty() || passField.getText().isEmpty()) {
                    JOptionPane.showMessageDialog(frame, "Tous les champs sont obligatoires.");
                    return;
                }
                manager.addEntry(new PasswordEntry(serviceField.getText(), userField.getText(), passField.getText()));
                refreshList(listModel);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, "Erreur ajout : " + ex.getMessage());
            }
        });

        updateButton.addActionListener(e -> {
            try {
                manager.updateEntry(serviceField.getText(), userField.getText(), passField.getText());
                refreshList(listModel);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, "Erreur modification : " + ex.getMessage());
            }
        });

        deleteButton.addActionListener(e -> {
            try {
                manager.deleteEntry(serviceField.getText(), userField.getText());
                refreshList(listModel);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, "Erreur suppression : " + ex.getMessage());
            }
        });

        frame.setVisible(true);
    }

    private static void refreshList(DefaultListModel<String> listModel) {
        try {
            listModel.clear();
            for (PasswordEntry entry : manager.getAllEntries()) {
                listModel.addElement(entry.getService() + " - " + entry.getUsername() + " : " + entry.getPassword());
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erreur chargement : " + e.getMessage());
        }
    }

    private static String hash(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] digest = md.digest(password.getBytes());
            return Base64.getEncoder().encodeToString(digest);
        } catch (Exception e) {
            return null;
        }
    }
}
